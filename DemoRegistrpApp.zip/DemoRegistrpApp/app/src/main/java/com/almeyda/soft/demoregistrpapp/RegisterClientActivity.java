package com.almeyda.soft.demoregistrpapp;

import android.os.Bundle;
import android.app.Activity;

public class RegisterClientActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_user_client);
    }

}
