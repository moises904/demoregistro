package com.almeyda.soft.demoregistrpapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;


public class LoginActivity extends AppCompatActivity {

    private Button btnLoguin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initializeView();

    }

    private void initializeView(){
        setContentView(R.layout.activity_login);
        btnLoguin = findViewById(R.id.btnLoguin);

        btnLoguin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToRegister();
            }
        });
    }

    private void goToRegister(){

        Intent intentRegister = new Intent(this, RegisterClientActivity.class);
        startActivity(intentRegister);
        finish();
    }
}
